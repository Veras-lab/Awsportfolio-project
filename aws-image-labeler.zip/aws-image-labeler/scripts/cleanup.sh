#!/usr/bin/env bash
# Deletes everything created by deploy.sh so nothing keeps costing money.
# Run from the repository root:  bash scripts/cleanup.sh
set -uo pipefail   # no -e: keep going if a resource is already gone

source "$(dirname "$0")/config.sh"
TOPIC_ARN="arn:aws:sns:${AWS_REGION}:${ACCOUNT_ID}:${TOPIC}"

echo "Cleaning up in $AWS_REGION (account $ACCOUNT_ID)..."

aws cloudwatch delete-alarms --alarm-names "$ALARM"
aws s3 rm "s3://$BUCKET" --recursive
aws s3api delete-bucket --bucket "$BUCKET"
aws lambda delete-function --function-name "$FUNCTION"
aws logs delete-log-group --log-group-name "/aws/lambda/$FUNCTION"
aws dynamodb delete-table --table-name "$TABLE" > /dev/null
aws sns delete-topic --topic-arn "$TOPIC_ARN"
aws iam delete-role-policy --role-name "$ROLE" --policy-name ImageLabelerPermissions
aws iam delete-role --role-name "$ROLE"

echo "Cleanup finished. Verify in the console that no resources remain."
