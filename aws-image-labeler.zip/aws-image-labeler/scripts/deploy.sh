#!/usr/bin/env bash
# Deploys the Image Labeler stack with the AWS CLI.
# Run from the repository root in AWS CloudShell:  bash scripts/deploy.sh
set -euo pipefail

source "$(dirname "$0")/config.sh"

if [[ -z "$NOTIFY_EMAIL" ]]; then
  echo "Set your email first:  export NOTIFY_EMAIL=you@example.com"
  exit 1
fi

echo "Account: $ACCOUNT_ID | Region: $AWS_REGION | Bucket: $BUCKET"

# 1. S3 bucket (new buckets block public access by default)
echo "[1/9] Creating S3 bucket..."
if [[ "$AWS_REGION" == "us-east-1" ]]; then
  aws s3api create-bucket --bucket "$BUCKET"
else
  aws s3api create-bucket --bucket "$BUCKET" \
    --create-bucket-configuration LocationConstraint="$AWS_REGION"
fi
aws s3api put-public-access-block --bucket "$BUCKET" \
  --public-access-block-configuration \
  BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true

# 2. DynamoDB table (on-demand billing = no idle cost)
echo "[2/9] Creating DynamoDB table..."
aws dynamodb create-table \
  --table-name "$TABLE" \
  --attribute-definitions AttributeName=ImageKey,AttributeType=S \
  --key-schema AttributeName=ImageKey,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST > /dev/null
aws dynamodb wait table-exists --table-name "$TABLE"

# 3. SNS topic + email subscription
echo "[3/9] Creating SNS topic..."
TOPIC_ARN="$(aws sns create-topic --name "$TOPIC" --query TopicArn --output text)"
aws sns subscribe --topic-arn "$TOPIC_ARN" --protocol email \
  --notification-endpoint "$NOTIFY_EMAIL" > /dev/null
echo "      >>> Check your inbox and CONFIRM the SNS subscription email <<<"

# 4. CloudWatch log group with short retention to limit storage cost
echo "[4/9] Creating log group (7-day retention)..."
aws logs create-log-group --log-group-name "/aws/lambda/$FUNCTION"
aws logs put-retention-policy --log-group-name "/aws/lambda/$FUNCTION" --retention-in-days 7

# 5. IAM role with least-privilege inline policy
echo "[5/9] Creating IAM role..."
aws iam create-role --role-name "$ROLE" \
  --assume-role-policy-document file://iam/lambda-trust-policy.json > /dev/null

sed -e "s|__REGION__|$AWS_REGION|g" \
    -e "s|__ACCOUNT_ID__|$ACCOUNT_ID|g" \
    -e "s|__FUNCTION__|$FUNCTION|g" \
    -e "s|__BUCKET__|$BUCKET|g" \
    -e "s|__TABLE__|$TABLE|g" \
    -e "s|__TOPIC_ARN__|$TOPIC_ARN|g" \
    iam/lambda-permissions-policy.json > /tmp/lambda-permissions-policy.json

aws iam put-role-policy --role-name "$ROLE" \
  --policy-name ImageLabelerPermissions \
  --policy-document file:///tmp/lambda-permissions-policy.json
ROLE_ARN="arn:aws:iam::${ACCOUNT_ID}:role/${ROLE}"

echo "      Waiting for IAM role to propagate..."
sleep 15

# 6. Package and create the Lambda function
echo "[6/9] Creating Lambda function..."
(cd lambda && zip -q -j /tmp/function.zip lambda_function.py)
aws lambda create-function \
  --function-name "$FUNCTION" \
  --runtime python3.12 \
  --handler lambda_function.lambda_handler \
  --role "$ROLE_ARN" \
  --zip-file fileb:///tmp/function.zip \
  --timeout 30 \
  --memory-size 256 \
  --environment "Variables={TABLE_NAME=$TABLE,SNS_TOPIC_ARN=$TOPIC_ARN,MAX_LABELS=10,MIN_CONFIDENCE=80}" \
  > /dev/null
aws lambda wait function-active --function-name "$FUNCTION"
LAMBDA_ARN="$(aws lambda get-function --function-name "$FUNCTION" \
  --query Configuration.FunctionArn --output text)"

# 7. Allow S3 to invoke the function (scoped to this bucket and account)
echo "[7/9] Granting S3 permission to invoke Lambda..."
aws lambda add-permission \
  --function-name "$FUNCTION" \
  --statement-id AllowS3Invoke \
  --action lambda:InvokeFunction \
  --principal s3.amazonaws.com \
  --source-arn "arn:aws:s3:::$BUCKET" \
  --source-account "$ACCOUNT_ID" > /dev/null

# 8. S3 event notification (only objects under uploads/)
echo "[8/9] Configuring S3 trigger..."
sed "s|__LAMBDA_ARN__|$LAMBDA_ARN|g" iam/s3-notification.json > /tmp/s3-notification.json
aws s3api put-bucket-notification-configuration \
  --bucket "$BUCKET" \
  --notification-configuration file:///tmp/s3-notification.json

# 9. CloudWatch alarm: email me if the function errors
echo "[9/9] Creating CloudWatch alarm..."
aws cloudwatch put-metric-alarm \
  --alarm-name "$ALARM" \
  --namespace AWS/Lambda \
  --metric-name Errors \
  --dimensions Name=FunctionName,Value="$FUNCTION" \
  --statistic Sum \
  --period 300 \
  --evaluation-periods 1 \
  --threshold 1 \
  --comparison-operator GreaterThanOrEqualToThreshold \
  --treat-missing-data notBreaching \
  --alarm-actions "$TOPIC_ARN"

echo
echo "Deployment complete."
echo "Test it:  aws s3 cp sample-images/<your-image>.jpg s3://$BUCKET/uploads/"
echo "Results:  aws dynamodb scan --table-name $TABLE"
