#!/usr/bin/env bash
# Shared settings for deploy.sh and cleanup.sh.
# Override any value by exporting it first, e.g.:  export NOTIFY_EMAIL=me@example.com

export AWS_REGION="${AWS_REGION:-us-east-1}"
export AWS_DEFAULT_REGION="$AWS_REGION"

ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"

BUCKET="image-labeler-${ACCOUNT_ID}-${AWS_REGION}"   # S3 bucket names must be globally unique
TABLE="ImageLabels"
FUNCTION="ImageLabelerFunction"
ROLE="ImageLabelerLambdaRole"
TOPIC="ImageLabelerAlerts"
ALARM="ImageLabeler-LambdaErrors"
NOTIFY_EMAIL="${NOTIFY_EMAIL:-}"
