# Sample images

Add 3-5 of your own `.jpg` or `.png` photos here for testing (a pet, a street, food, a laptop).
Use photos you own or royalty-free images (for example from Unsplash or Pexels).
Rekognition accepts JPEG and PNG up to 15 MB when read from S3.
