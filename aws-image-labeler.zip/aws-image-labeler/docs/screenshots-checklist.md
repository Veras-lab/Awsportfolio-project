# Screenshots to capture before running cleanup

Save these in `docs/` and link them from the main README.

1. `01-budget.png` - AWS Budgets alert configured
2. `02-s3-bucket.png` - S3 bucket with the `uploads/` folder and a test image
3. `03-iam-role.png` - the Lambda role's inline permissions policy
4. `04-lambda-function.png` - Lambda function with the S3 trigger shown
5. `05-dynamodb-results.png` - DynamoDB table items showing labels for an image
6. `06-sns-email.png` - the notification email you received
7. `07-cloudwatch-logs.png` - Lambda log output for a successful run
8. `08-cloudwatch-alarm.png` - the Errors alarm in OK state
9. `09-architecture.png` - architecture diagram (draw free at diagrams.net)
