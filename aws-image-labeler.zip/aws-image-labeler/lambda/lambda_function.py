"""
Image Labeler - AWS Lambda function.

Triggered by an S3 upload (ObjectCreated event). For each image it:
  1. Calls Amazon Rekognition DetectLabels
  2. Saves the labels + confidence scores to DynamoDB
  3. Optionally publishes a summary to an SNS topic (email)
"""
import logging
import os
import urllib.parse
from datetime import datetime, timezone
from decimal import Decimal

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

rekognition = boto3.client("rekognition")
dynamodb = boto3.resource("dynamodb")
sns = boto3.client("sns")

TABLE_NAME = os.environ["TABLE_NAME"]
SNS_TOPIC_ARN = os.environ.get("SNS_TOPIC_ARN", "")
MAX_LABELS = int(os.environ.get("MAX_LABELS", "10"))
MIN_CONFIDENCE = float(os.environ.get("MIN_CONFIDENCE", "80"))

SUPPORTED_EXTENSIONS = (".jpg", ".jpeg", ".png")  # formats Rekognition accepts

table = dynamodb.Table(TABLE_NAME)


def lambda_handler(event, context):
    processed = 0

    for record in event["Records"]:
        bucket = record["s3"]["bucket"]["name"]
        # S3 event keys are URL-encoded (spaces become '+')
        key = urllib.parse.unquote_plus(record["s3"]["object"]["key"])

        if not key.lower().endswith(SUPPORTED_EXTENSIONS):
            logger.info("Skipping unsupported file type: %s", key)
            continue

        logger.info("Analyzing s3://%s/%s", bucket, key)

        response = rekognition.detect_labels(
            Image={"S3Object": {"Bucket": bucket, "Name": key}},
            MaxLabels=MAX_LABELS,
            MinConfidence=MIN_CONFIDENCE,
        )

        # DynamoDB does not accept Python floats, so use Decimal
        labels = [
            {
                "Name": label["Name"],
                "Confidence": Decimal(str(round(label["Confidence"], 2))),
            }
            for label in response["Labels"]
        ]

        table.put_item(
            Item={
                "ImageKey": key,
                "Bucket": bucket,
                "ProcessedAt": datetime.now(timezone.utc).isoformat(),
                "LabelCount": len(labels),
                "Labels": labels,
            }
        )

        if SNS_TOPIC_ARN:
            summary = ", ".join(f"{l['Name']} ({l['Confidence']}%)" for l in labels)
            sns.publish(
                TopicArn=SNS_TOPIC_ARN,
                Subject="Image analyzed: " + key[:60],
                Message=f"Image: {key}\nLabels: {summary or 'none above threshold'}",
            )

        processed += 1

    logger.info("Processed %d image(s)", processed)
    return {"statusCode": 200, "processed": processed}
